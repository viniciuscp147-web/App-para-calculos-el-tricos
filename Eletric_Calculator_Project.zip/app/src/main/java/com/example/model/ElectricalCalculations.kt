package com.example.model

import java.util.Locale
import kotlin.math.sqrt

/**
 * Standard NBR 5410 Voltage Drop & Ampacity Calculations for flexible copper cables
 */
enum class CircuitType(val label: String, val kFactor: Double) {
    SINGLE_OR_TWO_PHASE("Monofásico / Bifásico (2 condutores)", 2.0),
    THREE_PHASE("Trifásico (3 ou 4 condutores)", sqrt(3.0)) // ~1.73205
}

enum class VoltageDropStatus(val title: String, val description: String, val isCompliant: Boolean) {
    COMPLIANT("Em Conformidade NBR 5410", "Queda de tensão e corrente dentro dos limites da NBR 5410.", true),
    WARNING("Atenção (Alimentador)", "Perda entre 4% e 7%. Aceitável apenas para alimentadores dedicados.", true),
    NON_COMPLIANT("Queda Excessiva (Não Conforme)", "Perda acima de 7%. Risco de perda de rendimento de aparelhos.", false),
    OVERCURRENT_HAZARD("Sobrecarga Térmica (Perigo)", "Cabo incompatível com a corrente! Risco de superaquecimento e incêndio.", false)
}

data class VoltageDropResult(
    val voltageDropVolts: Double,
    val voltageDropPercent: Double,
    val finalVoltageAtLoad: Double,
    val status: VoltageDropStatus,
    val suggestedSectionMm2: Double,
    val totalPowerLossWatts: Double,
    val cableMaxAmpacityA: Double,
    val isAmpacityExceeded: Boolean,
    val ampacityOverloadPercent: Double,
    val minSectionForCurrentMm2: Double,
    val ampacityWarningMessage: String?
)

object VoltageDropCalculator {
    // Resistividade do cobre eletrolítico em regime normal a 70°C conforme NBR 5410 (ohm * mm² / m)
    const val COPPER_RESISTIVITY_70C = 0.0210
    // Resistividade a 20°C
    const val COPPER_RESISTIVITY_20C = 0.0178

    fun calculate(
        distanceMeters: Double,
        sectionMm2: Double,
        currentAmperes: Double,
        nominalVoltageVolts: Double,
        circuitType: CircuitType,
        useOperatingTemp70C: Boolean = true
    ): VoltageDropResult {
        val selectedSectionInfo = StandardCableSections.getBySection(sectionMm2)
        val cableMaxAmpacity = selectedSectionInfo.nominalCurrentA
        val isAmpacityExceeded = currentAmperes > cableMaxAmpacity && currentAmperes > 0

        // Bitola mínima necessária apenas para a corrente (critério térmico de capacidade de condução)
        val minSectionForCurrent = StandardCableSections.ALL.firstOrNull { it.nominalCurrentA >= currentAmperes }?.sectionMm2
            ?: StandardCableSections.ALL.last().sectionMm2

        if (distanceMeters <= 0 || sectionMm2 <= 0 || currentAmperes <= 0 || nominalVoltageVolts <= 0) {
            return VoltageDropResult(
                voltageDropVolts = 0.0,
                voltageDropPercent = 0.0,
                finalVoltageAtLoad = nominalVoltageVolts,
                status = VoltageDropStatus.COMPLIANT,
                suggestedSectionMm2 = sectionMm2,
                totalPowerLossWatts = 0.0,
                cableMaxAmpacityA = cableMaxAmpacity,
                isAmpacityExceeded = false,
                ampacityOverloadPercent = 0.0,
                minSectionForCurrentMm2 = minSectionForCurrent,
                ampacityWarningMessage = null
            )
        }

        val rho = if (useOperatingTemp70C) COPPER_RESISTIVITY_70C else COPPER_RESISTIVITY_20C
        val k = circuitType.kFactor

        // Delta V = (k * rho * L * I) / S
        val deltaV = (k * rho * distanceMeters * currentAmperes) / sectionMm2
        val deltaVPercent = (deltaV / nominalVoltageVolts) * 100.0
        val finalVoltage = (nominalVoltageVolts - deltaV).coerceAtLeast(0.0)

        // Resistance R = rho * L / S (per wire)
        // Power loss P_loss = k * R * I^2
        val resistancePerWire = (rho * distanceMeters) / sectionMm2
        val powerLoss = when (circuitType) {
            CircuitType.SINGLE_OR_TWO_PHASE -> 2.0 * resistancePerWire * currentAmperes * currentAmperes
            CircuitType.THREE_PHASE -> 3.0 * resistancePerWire * currentAmperes * currentAmperes
        }

        // Bitola necessária para queda de tensão <= 4%
        val minSectionForVd = (k * rho * distanceMeters * currentAmperes) / (0.04 * nominalVoltageVolts)
        val suggestedSectionForVd = StandardCableSections.ALL.firstOrNull { it.sectionMm2 >= minSectionForVd }?.sectionMm2
            ?: StandardCableSections.ALL.last().sectionMm2

        // A bitola sugerida FINAL é o MAIOR entre o critério de queda de tensão e o critério de capacidade de corrente
        val finalSuggestedSection = maxOf(suggestedSectionForVd, minSectionForCurrent)

        val overloadPercent = if (isAmpacityExceeded && cableMaxAmpacity > 0) {
            ((currentAmperes - cableMaxAmpacity) / cableMaxAmpacity) * 100.0
        } else {
            0.0
        }

        val status = when {
            isAmpacityExceeded -> VoltageDropStatus.OVERCURRENT_HAZARD
            deltaVPercent <= 4.0 -> VoltageDropStatus.COMPLIANT
            deltaVPercent <= 7.0 -> VoltageDropStatus.WARNING
            else -> VoltageDropStatus.NON_COMPLIANT
        }

        val ampacityWarning = if (isAmpacityExceeded) {
            "ATENÇÃO: Este cabo de ${sectionMm2.toString().replace('.', ',')} mm² suporta no máximo ${cableMaxAmpacity.toInt()}A (NBR 5410). A corrente aplicada de ${"%.1f".format(Locale.US, currentAmperes).replace('.', ',')}A ultrapassa a capacidade em ${overloadPercent.toInt()}%, gerando risco de superaquecimento e derretimento do isolamento! Bitola mínima exigida para essa corrente: ${minSectionForCurrent.toString().replace('.', ',')} mm²."
        } else {
            null
        }

        return VoltageDropResult(
            voltageDropVolts = deltaV,
            voltageDropPercent = deltaVPercent,
            finalVoltageAtLoad = finalVoltage,
            status = status,
            suggestedSectionMm2 = finalSuggestedSection,
            totalPowerLossWatts = powerLoss,
            cableMaxAmpacityA = cableMaxAmpacity,
            isAmpacityExceeded = isAmpacityExceeded,
            ampacityOverloadPercent = overloadPercent,
            minSectionForCurrentMm2 = minSectionForCurrent,
            ampacityWarningMessage = ampacityWarning
        )
    }
}

/**
 * Power & Ohm's Law Calculator (P = V * I * FP)
 */
enum class PowerCalcMode(val title: String) {
    CALCULATE_CURRENT("Calcular Amperes (I)"),
    CALCULATE_POWER("Calcular Potência (P)"),
    CALCULATE_VOLTAGE("Calcular Tensão (V)"),
    SIZING_BY_AMPERES("Ampères ➔ Cabo Mínimo")
}

data class PowerCalcResult(
    val calculatedValue: Double,
    val unit: String,
    val formatted: String,
    val formulaUsed: String
)

object PowerCalculator {
    fun calculateCurrent(
        powerWatts: Double,
        voltageVolts: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val divisor = voltageVolts * factor * powerFactor.coerceIn(0.1, 1.0)
        val current = if (divisor > 0) powerWatts / divisor else 0.0

        val formula = if (isThreePhase) "I = P / (√3 × V × FP)" else "I = P / (V × FP)"
        return PowerCalcResult(
            calculatedValue = current,
            unit = "A",
            formatted = "%.2f A".format(Locale.US, current).replace('.', ','),
            formulaUsed = formula
        )
    }

    fun calculatePower(
        voltageVolts: Double,
        currentAmperes: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val powerWatts = voltageVolts * currentAmperes * factor * powerFactor.coerceIn(0.1, 1.0)

        val formula = if (isThreePhase) "P = √3 × V × I × FP" else "P = V × I × FP"
        val formatted = if (powerWatts >= 1000) {
            "%.2f kW (%.0f W)".format(Locale.US, powerWatts / 1000.0, powerWatts).replace('.', ',')
        } else {
            "%.1f W".format(Locale.US, powerWatts).replace('.', ',')
        }

        return PowerCalcResult(
            calculatedValue = powerWatts,
            unit = "W",
            formatted = formatted,
            formulaUsed = formula
        )
    }

    fun calculateVoltage(
        powerWatts: Double,
        currentAmperes: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val divisor = currentAmperes * factor * powerFactor.coerceIn(0.1, 1.0)
        val voltage = if (divisor > 0) powerWatts / divisor else 0.0

        val formula = if (isThreePhase) "V = P / (√3 × I × FP)" else "V = P / (I × FP)"
        return PowerCalcResult(
            calculatedValue = voltage,
            unit = "V",
            formatted = "%.1f V".format(Locale.US, voltage).replace('.', ','),
            formulaUsed = formula
        )
    }

    /**
     * Recomenda o cabo mínimo com base estritamente na capacidade de condução de corrente (Ampères)
     * Método B1 (condutores isolados em eletroduto embutido em alvenaria - NBR 5410 Tabela 36)
     */
    fun findMinCableForCurrent(currentAmperes: Double): CableSectionInfo {
        if (currentAmperes <= 0) return StandardCableSections.ALL.first()
        return StandardCableSections.ALL.firstOrNull { it.nominalCurrentA >= currentAmperes }
            ?: StandardCableSections.ALL.last()
    }
}
