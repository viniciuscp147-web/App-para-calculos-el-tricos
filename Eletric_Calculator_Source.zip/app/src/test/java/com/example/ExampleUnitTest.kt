package com.example

import com.example.model.BudgetItem
import com.example.model.CableColor
import com.example.model.CircuitType
import com.example.model.PowerCalculator
import com.example.model.StandardCableSections
import com.example.model.VoltageDropCalculator
import com.example.model.VoltageDropStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class ExampleUnitTest {

    @Test
    fun testVoltageDropSinglePhase() {
        // Distance 30m, 2.5 mm², 16A, 220V nominal, single phase (k = 2)
        // Delta V = (2 * 0.0210 * 30 * 16) / 2.5 = 20.16 / 2.5 = 8.064 V
        // Delta V% = (8.064 / 220) * 100 = 3.665% (Compliant <= 4%)
        val result = VoltageDropCalculator.calculate(
            distanceMeters = 30.0,
            sectionMm2 = 2.5,
            currentAmperes = 16.0,
            nominalVoltageVolts = 220.0,
            circuitType = CircuitType.SINGLE_OR_TWO_PHASE
        )

        assertEquals(8.064, result.voltageDropVolts, 0.05)
        assertEquals(3.665, result.voltageDropPercent, 0.05)
        assertEquals(VoltageDropStatus.COMPLIANT, result.status)
        assertTrue(result.status.isCompliant)
    }

    @Test
    fun testVoltageDropThreePhase() {
        // Distance 50m, 4.0 mm², 25A, 380V nominal, three phase (k = sqrt(3) ~ 1.732)
        // Delta V = (1.73205 * 0.0210 * 50 * 25) / 4.0 = 45.466 / 4.0 = 11.366 V
        // Delta V% = (11.366 / 380) * 100 = 2.99% (Compliant <= 4%)
        val result = VoltageDropCalculator.calculate(
            distanceMeters = 50.0,
            sectionMm2 = 4.0,
            currentAmperes = 25.0,
            nominalVoltageVolts = 380.0,
            circuitType = CircuitType.THREE_PHASE
        )

        assertEquals(11.366, result.voltageDropVolts, 0.1)
        assertEquals(2.99, result.voltageDropPercent, 0.1)
        assertEquals(VoltageDropStatus.COMPLIANT, result.status)
    }

    @Test
    fun testPowerCalculatorAmperesAndWatts() {
        // Calculate Current: 5500W at 220V, FP = 1.0 -> I = 5500 / 220 = 25.0 A
        val currentResult = PowerCalculator.calculateCurrent(5500.0, 220.0, 1.0, false)
        assertEquals(25.0, currentResult.calculatedValue, 0.01)

        // Calculate Power: 220V at 16A, FP = 1.0 -> P = 3520 W
        val powerResult = PowerCalculator.calculatePower(220.0, 16.0, 1.0, false)
        assertEquals(3520.0, powerResult.calculatedValue, 0.01)

        // Calculate Voltage: 4400W at 20A, FP = 1.0 -> V = 220 V
        val voltageResult = PowerCalculator.calculateVoltage(4400.0, 20.0, 1.0, false)
        assertEquals(220.0, voltageResult.calculatedValue, 0.01)
    }

    @Test
    fun testCableCalculationsForRollsAndCut() {
        val item = BudgetItem(
            sectionMm2 = 2.5,
            color = CableColor.BLUE,
            meters = 250.0,
            unitPricePerMeter = 4.55,
            rollDiscountPercent = 5.0
        )

        assertEquals(2, item.rolls100mCount)
        assertEquals(50.0, item.leftoverMeters, 0.001)
        val expectedRollPrice = 432.25
        assertEquals(expectedRollPrice, item.unitPricePerRoll100m, 0.01)
        val expectedTotal = (2 * expectedRollPrice) + (50 * 4.55)
        assertEquals(expectedTotal, item.totalPrice, 0.01)
    }
}
