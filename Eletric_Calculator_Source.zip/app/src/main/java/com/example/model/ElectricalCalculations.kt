package com.example.model

import java.util.Locale
import kotlin.math.sqrt

/**
 * Standard NBR 5410 Voltage Drop Calculations for flexible copper cables
 */
enum class CircuitType(val label: String, val kFactor: Double) {
    SINGLE_OR_TWO_PHASE("Monofásico / Bifásico (2 condutores)", 2.0),
    THREE_PHASE("Trifásico (3 ou 4 condutores)", sqrt(3.0)) // ~1.73205
}

enum class VoltageDropStatus(val title: String, val description: String, val isCompliant: Boolean) {
    COMPLIANT("Em Conformidade NBR 5410", "Perda dentro do limite máximo de 4% para circuitos terminais.", true),
    WARNING("Atenção (Alimentador)", "Perda entre 4% e 7%. Aceitável apenas para alimentadores dedicados.", true),
    NON_COMPLIANT("Queda Excessiva (Não Conforme)", "Perda acima de 7%. Risco de aquecimento e perda de rendimento. Aumente a bitola.", false)
}

data class VoltageDropResult(
    val voltageDropVolts: Double,
    val voltageDropPercent: Double,
    val finalVoltageAtLoad: Double,
    val status: VoltageDropStatus,
    val suggestedSectionMm2: Double,
    val totalPowerLossWatts: Double
)

object VoltageDropCalculator {
    // Resistividade do cobre eletrolítico em regime normal a 70°C conforme NBR 5410 (ohm * mm² / m)
    const val COPPER_RESISTIVITY_70C = 0.0210
    // Resistividade a 20°C
    const val COPPER_RESISTIVITY_20C = 0.0178

    fun calculate(
        distanceMeters: Double,
        sectionMm2: Double,
        currentAmperes: Double,
        nominalVoltageVolts: Double,
        circuitType: CircuitType,
        useOperatingTemp70C: Boolean = true
    ): VoltageDropResult {
        if (distanceMeters <= 0 || sectionMm2 <= 0 || currentAmperes <= 0 || nominalVoltageVolts <= 0) {
            return VoltageDropResult(
                voltageDropVolts = 0.0,
                voltageDropPercent = 0.0,
                finalVoltageAtLoad = nominalVoltageVolts,
                status = VoltageDropStatus.COMPLIANT,
                suggestedSectionMm2 = sectionMm2,
                totalPowerLossWatts = 0.0
            )
        }

        val rho = if (useOperatingTemp70C) COPPER_RESISTIVITY_70C else COPPER_RESISTIVITY_20C
        val k = circuitType.kFactor

        // Delta V = (k * rho * L * I) / S
        val deltaV = (k * rho * distanceMeters * currentAmperes) / sectionMm2
        val deltaVPercent = (deltaV / nominalVoltageVolts) * 100.0
        val finalVoltage = (nominalVoltageVolts - deltaV).coerceAtLeast(0.0)

        val status = when {
            deltaVPercent <= 4.0 -> VoltageDropStatus.COMPLIANT
            deltaVPercent <= 7.0 -> VoltageDropStatus.WARNING
            else -> VoltageDropStatus.NON_COMPLIANT
        }

        // Resistance R = rho * L / S (per wire)
        // Power loss P_loss = k * R * I^2
        val resistancePerWire = (rho * distanceMeters) / sectionMm2
        val powerLoss = when (circuitType) {
            CircuitType.SINGLE_OR_TWO_PHASE -> 2.0 * resistancePerWire * currentAmperes * currentAmperes
            CircuitType.THREE_PHASE -> 3.0 * resistancePerWire * currentAmperes * currentAmperes
        }

        // Calculate minimum section required to achieve max 4% drop:
        // S_min = (k * rho * L * I) / (0.04 * V_nom)
        val minSectionNeeded = (k * rho * distanceMeters * currentAmperes) / (0.04 * nominalVoltageVolts)
        val suggestedSection = StandardCableSections.ALL.firstOrNull { it.sectionMm2 >= minSectionNeeded }?.sectionMm2
            ?: StandardCableSections.ALL.last().sectionMm2

        return VoltageDropResult(
            voltageDropVolts = deltaV,
            voltageDropPercent = deltaVPercent,
            finalVoltageAtLoad = finalVoltage,
            status = status,
            suggestedSectionMm2 = suggestedSection,
            totalPowerLossWatts = powerLoss
        )
    }
}

/**
 * Power & Ohm's Law Calculator (P = V * I * FP)
 */
enum class PowerCalcMode(val title: String) {
    CALCULATE_CURRENT("Calcular Amperes (I)"),
    CALCULATE_POWER("Calcular Potência (P)"),
    CALCULATE_VOLTAGE("Calcular Tensão (V)")
}

data class PowerCalcResult(
    val calculatedValue: Double,
    val unit: String,
    val formatted: String,
    val formulaUsed: String
)

object PowerCalculator {
    fun calculateCurrent(
        powerWatts: Double,
        voltageVolts: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val divisor = voltageVolts * factor * powerFactor.coerceIn(0.1, 1.0)
        val current = if (divisor > 0) powerWatts / divisor else 0.0

        val formula = if (isThreePhase) "I = P / (√3 × V × FP)" else "I = P / (V × FP)"
        return PowerCalcResult(
            calculatedValue = current,
            unit = "A",
            formatted = "%.2f A".format(Locale.US, current).replace('.', ','),
            formulaUsed = formula
        )
    }

    fun calculatePower(
        voltageVolts: Double,
        currentAmperes: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val powerWatts = voltageVolts * currentAmperes * factor * powerFactor.coerceIn(0.1, 1.0)

        val formula = if (isThreePhase) "P = √3 × V × I × FP" else "P = V × I × FP"
        val formatted = if (powerWatts >= 1000) {
            "%.2f kW (%.0f W)".format(Locale.US, powerWatts / 1000.0, powerWatts).replace('.', ',')
        } else {
            "%.1f W".format(Locale.US, powerWatts).replace('.', ',')
        }

        return PowerCalcResult(
            calculatedValue = powerWatts,
            unit = "W",
            formatted = formatted,
            formulaUsed = formula
        )
    }

    fun calculateVoltage(
        powerWatts: Double,
        currentAmperes: Double,
        powerFactor: Double = 1.0,
        isThreePhase: Boolean = false
    ): PowerCalcResult {
        val factor = if (isThreePhase) sqrt(3.0) else 1.0
        val divisor = currentAmperes * factor * powerFactor.coerceIn(0.1, 1.0)
        val voltage = if (divisor > 0) powerWatts / divisor else 0.0

        val formula = if (isThreePhase) "V = P / (√3 × I × FP)" else "V = P / (I × FP)"
        return PowerCalcResult(
            calculatedValue = voltage,
            unit = "V",
            formatted = "%.1f V".format(Locale.US, voltage).replace('.', ','),
            formulaUsed = formula
        )
    }
}
