package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CircuitType
import com.example.model.StandardCableSections
import com.example.model.VoltageDropResult
import com.example.model.VoltageDropStatus
import com.example.viewmodel.AppTab
import com.example.viewmodel.CableViewModel
import java.util.Locale

@Composable
fun VoltageDropScreen(
    viewModel: CableViewModel,
    modifier: Modifier = Modifier
) {
    val distance by viewModel.vdDistance.collectAsState()
    val section by viewModel.vdSection.collectAsState()
    val current by viewModel.vdCurrent.collectAsState()
    val voltage by viewModel.vdVoltage.collectAsState()
    val circuitType by viewModel.vdCircuitType.collectAsState()

    val result = viewModel.getVoltageDropResult()
    val scrollState = rememberScrollState()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("voltage_drop_screen")
    ) {
        val isWide = maxWidth >= 720.dp

        if (isWide) {
            // DESKTOP / TABLET TWO-COLUMN SIDE-BY-SIDE LAYOUT
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // LEFT PANE: Inputs Form
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = "Cálculo de Queda de Tensão",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Dimensionamento por perda máxima admissível conforme NBR 5410",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    CircuitTypeSelector(circuitType = circuitType, onSelect = { viewModel.setVdCircuitType(it) })

                    Spacer(modifier = Modifier.height(16.dp))

                    DistanceAndCurrentInputs(
                        distance = distance,
                        onDistanceChange = { viewModel.setVdDistance(it) },
                        current = current,
                        onCurrentChange = { viewModel.setVdCurrent(it) }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    VoltageInput(voltage = voltage, onVoltageChange = { viewModel.setVdVoltage(it) })

                    Spacer(modifier = Modifier.height(16.dp))

                    SectionSelector(
                        selectedSection = section,
                        onSectionSelect = { viewModel.setVdSection(it) }
                    )
                }

                // RIGHT PANE: Results Card & Action
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .verticalScroll(rememberScrollState())
                ) {
                    VoltageDropResultCard(result = result)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.selectSection(section)
                            viewModel.setMetersInput(distance)
                            viewModel.setTab(AppTab.CABLE_PRICES)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Ver Preço e Tabela desta Bitola (${section.toString().replace('.', ',')} mm²)")
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        } else {
            // MOBILE SINGLE COLUMN VERTICAL LAYOUT
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Cálculo de Queda de Tensão",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Dimensionamento por perda máxima admissível conforme NBR 5410",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Spacer(modifier = Modifier.height(14.dp))

                CircuitTypeSelector(circuitType = circuitType, onSelect = { viewModel.setVdCircuitType(it) })

                Spacer(modifier = Modifier.height(14.dp))

                DistanceAndCurrentInputs(
                    distance = distance,
                    onDistanceChange = { viewModel.setVdDistance(it) },
                    current = current,
                    onCurrentChange = { viewModel.setVdCurrent(it) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                VoltageInput(voltage = voltage, onVoltageChange = { viewModel.setVdVoltage(it) })

                Spacer(modifier = Modifier.height(14.dp))

                SectionSelector(
                    selectedSection = section,
                    onSectionSelect = { viewModel.setVdSection(it) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                VoltageDropResultCard(result = result)

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.selectSection(section)
                        viewModel.setMetersInput(distance)
                        viewModel.setTab(AppTab.CABLE_PRICES)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Ver Preço e Tabela desta Bitola (${section.toString().replace('.', ',')} mm²)")
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun CircuitTypeSelector(
    circuitType: CircuitType,
    onSelect: (CircuitType) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable { onSelect(CircuitType.SINGLE_OR_TWO_PHASE) },
            color = if (circuitType == CircuitType.SINGLE_OR_TWO_PHASE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Monofásico / Bifásico",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (circuitType == CircuitType.SINGLE_OR_TWO_PHASE) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "2 condutores (k = 2)",
                    fontSize = 10.sp,
                    color = if (circuitType == CircuitType.SINGLE_OR_TWO_PHASE) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }

        Surface(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable { onSelect(CircuitType.THREE_PHASE) },
            color = if (circuitType == CircuitType.THREE_PHASE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Trifásico Equilibrado",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (circuitType == CircuitType.THREE_PHASE) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "3/4 condutores (k = √3)",
                    fontSize = 10.sp,
                    color = if (circuitType == CircuitType.THREE_PHASE) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
private fun DistanceAndCurrentInputs(
    distance: String,
    onDistanceChange: (String) -> Unit,
    current: String,
    onCurrentChange: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = distance,
            onValueChange = onDistanceChange,
            label = { Text("Distância (m)") },
            modifier = Modifier
                .weight(1f)
                .testTag("distance_input"),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
            value = current,
            onValueChange = onCurrentChange,
            label = { Text("Corrente (A)") },
            modifier = Modifier
                .weight(1f)
                .testTag("current_input"),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
private fun VoltageInput(
    voltage: String,
    onVoltageChange: (String) -> Unit
) {
    Column {
        OutlinedTextField(
            value = voltage,
            onValueChange = onVoltageChange,
            label = { Text("Tensão Nominal da Rede (V)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voltage_input"),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("127", "220", "380", "440").forEach { v ->
                FilledTonalButton(
                    onClick = { onVoltageChange(v) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 2.dp, horizontal = 2.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("${v}V", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun SectionSelector(
    selectedSection: Double,
    onSectionSelect: (Double) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Seção do Cabo (mm²):",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "${selectedSection.toString().replace('.', ',')} mm² selecionado",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(StandardCableSections.ALL) { sec ->
                val isSelected = sec.sectionMm2 == selectedSection
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSectionSelect(sec.sectionMm2) }
                        .testTag("vd_section_${sec.sectionMm2}"),
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = sec.displayLabel,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VoltageDropResultCard(result: VoltageDropResult) {
    val statusColor = when (result.status) {
        VoltageDropStatus.COMPLIANT -> Color(0xFF16A34A)
        VoltageDropStatus.WARNING -> Color(0xFFD97706)
        VoltageDropStatus.NON_COMPLIANT -> Color(0xFFDC2626)
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("voltage_drop_result_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (result.status.isCompliant) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = result.status.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = statusColor
                        )
                    }
                }

                Text(
                    text = "Limite NBR: 4,0%",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "Perda de Tensão (%)",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "%.2f%%".format(Locale.US, result.voltageDropPercent).replace('.', ','),
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.Black,
                            color = statusColor
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Queda em Volts (ΔV)",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "%.2f V".format(Locale.US, result.voltageDropVolts).replace('.', ','),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val progress = (result.voltageDropPercent / 10.0).toFloat().coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = statusColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Tensão restante na Carga:", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "%.2f V".format(Locale.US, result.finalVoltageAtLoad).replace('.', ','),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Potência dissipada no cabo:", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "%.1f Watts".format(Locale.US, result.totalPowerLossWatts).replace('.', ','),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (result.status == VoltageDropStatus.NON_COMPLIANT) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recomendação NBR: Aumente para no mínimo ${result.suggestedSectionMm2.toString().replace('.', ',')} mm² para manter a queda abaixo de 4%.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        )
                    }
                }
            }
        }
    }
}
